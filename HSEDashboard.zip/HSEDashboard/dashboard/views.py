from django.shortcuts import render
from . models import Injuries
from django.db.models import Sum

# Create your views here.

def dashboard(request):

	last_year = Injuries.objects.filter(incident_date__range=('2019-1-1 00:00:00+00:00', '2019-12-31 23:59:59+00:00'))
	this_year = Injuries.objects.filter(incident_date__range=('2020-1-1 00:00:00+00:00', '2020-11-30 23:59:59+00:00'))
	this_month = Injuries.objects.filter(incident_date__range=('2020-12-1 00:00:00+00:00', '2020-12-31 23:59:59+00:00'))

	this_month_fatalities = this_month.aggregate(Sum('fatalities'))['fatalities__sum']
	this_month_injuries = this_month.aggregate(Sum('injuries'))['injuries__sum']
	this_month_fire = this_month.aggregate(Sum('fire'))['fire__sum']
	this_month_spills = this_month.aggregate(Sum('spills'))['spills__sum']
	this_month_rollovers = this_month.aggregate(Sum('rollovers'))['rollovers__sum']
	this_month_motor_vehicle_accidents = this_month.aggregate(Sum('motor_vehicle_accidents'))['motor_vehicle_accidents__sum']
	this_month_incidents = this_month.aggregate(Sum('incidents'))['incidents__sum']
	
	this_year_fatalities = this_year.aggregate(Sum('fatalities'))['fatalities__sum']
	this_year_injuries = this_year.aggregate(Sum('injuries'))['injuries__sum']
	this_year_fire = this_year.aggregate(Sum('fire'))['fire__sum']
	this_year_spills = this_year.aggregate(Sum('spills'))['spills__sum']
	this_year_rollovers = this_year.aggregate(Sum('rollovers'))['rollovers__sum']
	this_year_motor_vehicle_accidents = this_year.aggregate(Sum('motor_vehicle_accidents'))['motor_vehicle_accidents__sum']
	this_year_incidents = this_year.aggregate(Sum('incidents'))['incidents__sum']
	
	last_year_fatalities = last_year.aggregate(Sum('fatalities'))['fatalities__sum']
	last_year_injuries = last_year.aggregate(Sum('injuries'))['injuries__sum']
	last_year_fire = last_year.aggregate(Sum('fire'))['fire__sum']
	last_year_spills = last_year.aggregate(Sum('spills'))['spills__sum']
	last_year_rollovers = last_year.aggregate(Sum('rollovers'))['rollovers__sum']
	last_year_motor_vehicle_accidents = last_year.aggregate(Sum('motor_vehicle_accidents'))['motor_vehicle_accidents__sum']
	last_year_incidents = last_year.aggregate(Sum('incidents'))['incidents__sum']

	context = {
		'this_month_fatalities': this_month_fatalities,
		'this_month_injuries': this_month_injuries,
		'this_month_fire': this_month_fire,
		'this_month_spills': this_month_spills,
		'this_month_rollovers': this_month_rollovers,
		'this_month_motor_vehicle_accidents': this_month_motor_vehicle_accidents,
		'this_month_incidents': this_month_incidents,
		'this_year_fatalities': this_year_fatalities,
		'this_year_injuries': this_year_injuries,
		'this_year_fire': this_year_fire,
		'this_year_spills': this_year_spills,
		'this_year_rollovers': this_year_rollovers,
		'this_year_motor_vehicle_accidents': this_year_motor_vehicle_accidents,
		'this_year_incidents': this_year_incidents,
		'last_year_fatalities': last_year_fatalities,
		'last_year_injuries': last_year_injuries,
		'last_year_fire': last_year_fire,
		'last_year_spills': last_year_spills,
		'last_year_rollovers': last_year_rollovers,
		'last_year_motor_vehicle_accidents': last_year_motor_vehicle_accidents,
		'last_year_incidents': last_year_incidents,
	}

	return render(request, 'dashboard/dashboard.html', context)
	