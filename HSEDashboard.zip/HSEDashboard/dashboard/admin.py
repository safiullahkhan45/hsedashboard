from django.contrib import admin
from . models import Injuries

# Register your models here.
admin.site.register(Injuries)
