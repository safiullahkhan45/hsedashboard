from django.db import models

# Create your models here.
class Injuries(models.Model):
	fatalities = models.IntegerField()
	injuries = models.IntegerField()
	fire = models.IntegerField()
	spills = models.IntegerField()
	rollovers = models.IntegerField()
	motor_vehicle_accidents = models.IntegerField()
	incidents = models.IntegerField()
	incident_date = models.DateTimeField()

	def __str__(self):
		return str(self.incident_date)


	class Meta:

		verbose_name_plural = 'Injuries'
